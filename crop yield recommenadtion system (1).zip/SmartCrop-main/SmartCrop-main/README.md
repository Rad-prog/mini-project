**SmartCrop** aims to provide farmers with a tool to optimize crop selection decisions based on scientific data analysis. By using machine learning techniques, the application aims to enhance agricultural productivity and sustainability by recommending crops well-suited to specific environmental conditions.

![image](https://github.com/darrinbright/SmartCrop/assets/85438610/5f5c1108-2c1e-41fb-83e6-b69b3b1301cb)

![image](https://github.com/darrinbright/SmartCrop/assets/85438610/5b3145be-6831-43d6-907d-fcbbe4d1cc51)
